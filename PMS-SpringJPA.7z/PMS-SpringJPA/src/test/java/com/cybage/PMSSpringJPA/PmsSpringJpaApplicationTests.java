package com.cybage.PMSSpringJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsSpringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
